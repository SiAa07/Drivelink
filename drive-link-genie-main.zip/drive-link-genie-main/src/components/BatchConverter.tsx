
import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { processBatchLinks, generateLinkPreview } from "../utils/linkUtils";
import { useCopyToClipboard } from "../hooks/useCopyToClipboard";
import { useLocalStorage } from "../hooks/useLocalStorage";
import { FileText, Copy, ArrowRight, Check, XCircle, CheckCircle2, ExternalLink, List } from "lucide-react";
import { toast } from "../components/ui/use-toast";

interface BatchResult {
  id: string;
  links: {
    originalUrl: string;
    directUrl: string;
    success: boolean;
    message?: string;
  }[];
  timestamp: number;
}

const BatchConverter = () => {
  const [inputUrls, setInputUrls] = useState("");
  const [results, setResults] = useState<BatchResult | null>(null);
  const [isConverting, setIsConverting] = useState(false);
  const [copyLink, copyState] = useCopyToClipboard();
  const [history, setHistory] = useLocalStorage<BatchResult[]>("drive-links-batch-history", []);

  const handleProcessBatch = (e: React.FormEvent) => {
    e.preventDefault();
    
    const urls = inputUrls
      .split("\n")
      .map(url => url.trim())
      .filter(url => url !== "");
    
    if (urls.length === 0) {
      toast({
        title: "No URLs provided",
        description: "Please enter at least one Google Drive URL.",
        variant: "destructive",
      });
      return;
    }
    
    setIsConverting(true);
    
    // Simulate processing time for better UX
    setTimeout(() => {
      const batchResults = processBatchLinks(urls);
      
      const newBatchResult: BatchResult = {
        id: Date.now().toString(),
        links: batchResults,
        timestamp: Date.now()
      };
      
      setResults(newBatchResult);
      
      // Only store in history if at least one successful conversion
      if (batchResults.some(r => r.success)) {
        setHistory(prev => [newBatchResult, ...prev].slice(0, 10)); // Keep only last 10 batch results
      }
      
      setIsConverting(false);
      
      const successCount = batchResults.filter(r => r.success).length;
      
      toast({
        title: `Processed ${urls.length} URLs`,
        description: `Successfully converted ${successCount} out of ${urls.length} links.`,
        variant: successCount > 0 ? "default" : "destructive",
      });
    }, 1000);
  };
  
  const handleCopyAllLinks = async () => {
    if (results?.links) {
      const successfulLinks = results.links
        .filter(link => link.success)
        .map(link => link.directUrl)
        .join("\n");
      
      if (successfulLinks) {
        const copied = await copyLink(successfulLinks);
        if (copied) {
          toast({
            title: "Links copied",
            description: "All successful direct download links copied to clipboard!",
          });
        } else {
          toast({
            title: "Copy failed",
            description: "Failed to copy links to clipboard.",
            variant: "destructive",
          });
        }
      } else {
        toast({
          title: "No links to copy",
          description: "There are no successful links to copy.",
          variant: "destructive",
        });
      }
    }
  };
  
  const handleCopyLink = async (url: string) => {
    const copied = await copyLink(url);
    if (copied) {
      toast({
        title: "Link copied",
        description: "Direct download link copied to clipboard!",
      });
    }
  };
  
  const handleClear = () => {
    setInputUrls("");
    setResults(null);
  };

  return (
    <motion.div
      id="batch"
      className="w-full max-w-3xl mx-auto px-4 py-16"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
    >
      <div className="text-center mb-8">
        <motion.div
          className="inline-block p-3 rounded-full bg-primary/10 mb-4"
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.5 }}
        >
          <List size={28} className="text-primary" />
        </motion.div>
        <motion.h2
          className="text-3xl font-bold tracking-tight mb-2"
          initial={{ y: 10, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.5 }}
        >
          Batch Link Processing
        </motion.h2>
        <motion.p
          className="text-muted-foreground max-w-md mx-auto"
          initial={{ y: 10, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.5 }}
        >
          Convert multiple Google Drive links at once
        </motion.p>
      </div>

      <motion.div
        className="glass-card rounded-2xl p-8"
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.6, duration: 0.5 }}
      >
        <form onSubmit={handleProcessBatch} className="space-y-4">
          <div className="space-y-2">
            <label htmlFor="batchUrls" className="text-sm font-medium">
              Enter Google Drive URLs (one per line)
            </label>
            <textarea
              id="batchUrls"
              value={inputUrls}
              onChange={(e) => setInputUrls(e.target.value)}
              placeholder="https://drive.google.com/file/d/...\nhttps://drive.google.com/file/d/..."
              className="glass-input w-full h-40 p-4 rounded-xl text-sm transition-all duration-300 resize-none"
            />
          </div>

          <div className="flex items-center justify-between gap-4 pt-2">
            {results && (
              <button
                type="button"
                onClick={handleClear}
                className="px-4 py-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors rounded-lg"
              >
                Clear
              </button>
            )}
            
            <motion.button
              type="submit"
              disabled={isConverting || !inputUrls.trim()}
              className={`ml-auto px-6 py-2.5 rounded-xl bg-primary text-primary-foreground font-medium text-sm transition-all duration-300 ${
                isConverting || !inputUrls.trim()
                  ? "opacity-70 cursor-not-allowed"
                  : "hover:bg-primary/90"
              }`}
              whileHover={{ scale: isConverting || !inputUrls.trim() ? 1 : 1.03 }}
              whileTap={{ scale: isConverting || !inputUrls.trim() ? 1 : 0.98 }}
            >
              {isConverting ? (
                <span className="flex items-center gap-2">
                  <svg className="animate-spin h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Processing...
                </span>
              ) : (
                <span className="flex items-center gap-2">
                  Process Batch <ArrowRight size={16} />
                </span>
              )}
            </motion.button>
          </div>
        </form>

        <AnimatePresence>
          {results && results.links.length > 0 && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
              className="mt-8 pt-6 border-t border-border"
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-medium">Processing Results</h3>
                    <span className="px-2 py-0.5 text-xs rounded-full bg-secondary text-muted-foreground">
                      {results.links.filter(r => r.success).length}/{results.links.length} Successful
                    </span>
                  </div>
                  
                  {results.links.some(r => r.success) && (
                    <button
                      onClick={handleCopyAllLinks}
                      className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg bg-secondary/70 hover:bg-secondary transition-colors"
                    >
                      <Copy size={14} /> Copy All
                    </button>
                  )}
                </div>
                
                <div className="space-y-3 max-h-80 overflow-y-auto p-1">
                  {results.links.map((link, index) => (
                    <div
                      key={index}
                      className="bg-secondary/30 rounded-xl p-3 flex items-start gap-2"
                    >
                      <div className={`mt-0.5 p-1 rounded-full flex-shrink-0 ${link.success ? "bg-green-100 text-green-600" : "bg-red-100 text-red-600"}`}>
                        {link.success ? <CheckCircle2 size={16} /> : <XCircle size={16} />}
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <p className="text-xs text-muted-foreground mb-1">
                          {generateLinkPreview(link.originalUrl)}
                        </p>
                        
                        {link.success ? (
                          <div className="flex items-center justify-between gap-2">
                            <p className="text-xs font-medium truncate max-w-[70%]">
                              {generateLinkPreview(link.directUrl)}
                            </p>
                            <div className="flex items-center gap-1">
                              <a
                                href={link.directUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="p-1.5 rounded-md hover:bg-secondary transition-colors"
                                aria-label="Open direct link"
                              >
                                <ExternalLink size={14} className="text-muted-foreground" />
                              </a>
                              <button
                                onClick={() => handleCopyLink(link.directUrl)}
                                className="p-1.5 rounded-md hover:bg-secondary transition-colors"
                                aria-label="Copy direct link"
                              >
                                {copyState.copied && copyState.text === link.directUrl ? (
                                  <Check size={14} className="text-green-600" />
                                ) : (
                                  <Copy size={14} className="text-muted-foreground" />
                                )}
                              </button>
                            </div>
                          </div>
                        ) : (
                          <p className="text-xs text-red-500">
                            {link.message || "Failed to convert link"}
                          </p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </motion.div>
  );
};

export default BatchConverter;
