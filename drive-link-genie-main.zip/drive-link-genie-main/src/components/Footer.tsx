
import { motion } from "framer-motion";
import { Heart, Github } from "lucide-react";

const Footer = () => {
  return (
    <motion.footer
      className="w-full mt-auto pt-12 pb-8 px-6"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.8, duration: 0.5 }}
    >
      <div className="container mx-auto">
        <div className="border-t border-border pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <p className="text-sm text-muted-foreground">
                &copy; {new Date().getFullYear()} DriveLink Generator. All rights reserved.
              </p>
            </div>
            
            <div className="flex items-center gap-4">
              <a
                href="#"
                className="text-muted-foreground hover:text-foreground transition-colors"
                aria-label="GitHub"
              >
                <Github size={18} />
              </a>
              <p className="text-sm text-muted-foreground flex items-center">
                Made with <Heart size={14} className="mx-1 text-red-400" /> for the community
              </p>
            </div>
          </div>
          
          <div className="mt-6 text-center text-xs text-muted-foreground">
            <p>
              This tool is for educational purposes only. Please respect the terms of service of Google Drive.
            </p>
          </div>
        </div>
      </div>
    </motion.footer>
  );
};

export default Footer;
