
import { motion } from "framer-motion";
import { useState, useEffect } from "react";
import { FileText, Link } from "lucide-react";

const Header = () => {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <motion.header
      className={`fixed top-0 left-0 right-0 z-50 py-4 px-6 transition-all duration-300 ${
        scrolled ? "bg-white/80 backdrop-blur-md shadow-sm" : "bg-transparent"
      }`}
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
    >
      <div className="container mx-auto flex items-center justify-between">
        <motion.div
          className="flex items-center gap-2"
          initial={{ x: -20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.5 }}
        >
          <div className="rounded-lg bg-primary/10 p-2">
            <Link size={24} className="text-primary" />
          </div>
          <div>
            <h1 className="text-xl font-semibold tracking-tight">DriveLink</h1>
            <p className="text-xs text-muted-foreground">Direct Download Generator</p>
          </div>
        </motion.div>
        
        <motion.div
          initial={{ x: 20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.5 }}
        >
          <div className="hidden sm:flex items-center gap-6">
            <a href="#converter" className="text-sm font-medium animate-link">Convert Links</a>
            <a href="#batch" className="text-sm font-medium animate-link">Batch Process</a>
            <a href="#history" className="text-sm font-medium animate-link">History</a>
            <motion.a
              href="#how-it-works"
              className="text-sm font-medium bg-primary/10 text-primary px-4 py-2 rounded-full transition-colors hover:bg-primary/20"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              How It Works
            </motion.a>
          </div>
        </motion.div>
      </div>
    </motion.header>
  );
};

export default Header;
