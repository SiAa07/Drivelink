
import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useLocalStorage } from "../hooks/useLocalStorage";
import { useCopyToClipboard } from "../hooks/useCopyToClipboard";
import { History, Copy, Check, ExternalLink, Trash2, Clock } from "lucide-react";
import { toast } from "../components/ui/use-toast";
import { generateLinkPreview } from "../utils/linkUtils";

interface LinkHistoryItem {
  id: string;
  originalUrl: string;
  directUrl: string;
  timestamp: number;
  success: boolean;
}

const LinkHistory = () => {
  const [history, setHistory] = useLocalStorage<LinkHistoryItem[]>(
    "drive-links-history",
    []
  );
  const [copyLink, copyState] = useCopyToClipboard();

  const handleCopyLink = async (url: string) => {
    const copied = await copyLink(url);
    if (copied) {
      toast({
        title: "Link copied",
        description: "Direct download link copied to clipboard!",
      });
    }
  };

  const handleDeleteItem = (id: string) => {
    setHistory((prev) => prev.filter((item) => item.id !== id));
    toast({
      title: "Link removed",
      description: "Link was removed from your history.",
    });
  };

  const handleClearHistory = () => {
    setHistory([]);
    toast({
      title: "History cleared",
      description: "Your link history has been cleared.",
    });
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleString(undefined, {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  return (
    <motion.div
      id="history"
      className="w-full max-w-3xl mx-auto px-4 py-16"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.3 }}
    >
      <div className="text-center mb-8">
        <motion.div
          className="inline-block p-3 rounded-full bg-primary/10 mb-4"
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.5 }}
        >
          <History size={28} className="text-primary" />
        </motion.div>
        <motion.h2
          className="text-3xl font-bold tracking-tight mb-2"
          initial={{ y: 10, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.5 }}
        >
          Link History
        </motion.h2>
        <motion.p
          className="text-muted-foreground max-w-md mx-auto"
          initial={{ y: 10, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.6, duration: 0.5 }}
        >
          Access your previously converted links
        </motion.p>
      </div>

      <motion.div
        className="glass-card rounded-2xl p-8"
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.7, duration: 0.5 }}
      >
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-medium">Recent Links</h3>
          {history.length > 0 && (
            <button
              onClick={handleClearHistory}
              className="text-xs px-3 py-1.5 rounded-lg text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors"
            >
              Clear All
            </button>
          )}
        </div>

        <AnimatePresence>
          {history.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="text-center py-12"
            >
              <div className="mb-3 inline-flex items-center justify-center w-16 h-16 rounded-full bg-muted/50">
                <Clock size={24} className="text-muted-foreground" />
              </div>
              <h4 className="text-base font-medium mb-1">No history yet</h4>
              <p className="text-sm text-muted-foreground">
                Convert some links to see your history here
              </p>
            </motion.div>
          ) : (
            <motion.div
              layout
              className="space-y-3 max-h-96 overflow-y-auto pr-1"
            >
              {history.map((item) => (
                <motion.div
                  key={item.id}
                  layout
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                  className="link-item bg-secondary/30 hover:bg-secondary/50 rounded-xl p-4 transition-colors"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center gap-3 justify-between">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="text-xs text-muted-foreground bg-muted/50 px-2 py-0.5 rounded-full flex items-center gap-1">
                          <Clock size={12} /> {formatDate(item.timestamp)}
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground mb-1 truncate">
                        {generateLinkPreview(item.originalUrl)}
                      </p>
                      <p className="text-sm font-medium truncate">
                        {generateLinkPreview(item.directUrl)}
                      </p>
                    </div>
                    
                    <div className="flex items-center gap-1 self-end sm:self-auto">
                      <a
                        href={item.directUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-2 rounded-lg hover:bg-secondary transition-colors"
                        aria-label="Open direct link"
                      >
                        <ExternalLink size={16} className="text-muted-foreground" />
                      </a>
                      <button
                        onClick={() => handleCopyLink(item.directUrl)}
                        className="p-2 rounded-lg hover:bg-secondary transition-colors"
                        aria-label="Copy direct link"
                      >
                        {copyState.copied && copyState.text === item.directUrl ? (
                          <Check size={16} className="text-green-600" />
                        ) : (
                          <Copy size={16} className="text-muted-foreground" />
                        )}
                      </button>
                      <button
                        onClick={() => handleDeleteItem(item.id)}
                        className="p-2 rounded-lg hover:bg-secondary transition-colors"
                        aria-label="Remove from history"
                      >
                        <Trash2 size={16} className="text-muted-foreground" />
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </motion.div>
  );
};

export default LinkHistory;
