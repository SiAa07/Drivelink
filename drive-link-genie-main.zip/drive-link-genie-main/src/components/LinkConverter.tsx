
import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { convertToDriveDirectLink, isValidDriveUrl } from "../utils/linkUtils";
import { useCopyToClipboard } from "../hooks/useCopyToClipboard";
import { useLocalStorage } from "../hooks/useLocalStorage";
import { Link, Copy, ArrowRight, Check, AlertCircle, XCircle, ExternalLink } from "lucide-react";
import { toast } from "../components/ui/use-toast";

interface ConversionResult {
  id: string;
  originalUrl: string;
  directUrl: string;
  timestamp: number;
  success: boolean;
  message?: string;
}

const LinkConverter = () => {
  const [inputUrl, setInputUrl] = useState("");
  const [isValidUrl, setIsValidUrl] = useState(true);
  const [result, setResult] = useState<ConversionResult | null>(null);
  const [isConverting, setIsConverting] = useState(false);
  const [copyLink, copyState] = useCopyToClipboard();
  const [history, setHistory] = useLocalStorage<ConversionResult[]>("drive-links-history", []);

  // Check URL validity on input change
  useEffect(() => {
    if (inputUrl && !isValidDriveUrl(inputUrl)) {
      setIsValidUrl(false);
    } else {
      setIsValidUrl(true);
    }
  }, [inputUrl]);

  const handleConvert = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!inputUrl.trim()) {
      toast({
        title: "Please enter a URL",
        description: "You need to enter a Google Drive URL to convert.",
        variant: "destructive",
      });
      return;
    }
    
    if (!isValidDriveUrl(inputUrl)) {
      toast({
        title: "Invalid URL format",
        description: "Please enter a valid Google Drive URL.",
        variant: "destructive",
      });
      return;
    }
    
    setIsConverting(true);
    
    // Simulate processing time for user experience
    setTimeout(() => {
      const conversionResult = convertToDriveDirectLink(inputUrl);
      
      const newResult: ConversionResult = {
        id: Date.now().toString(),
        originalUrl: inputUrl,
        directUrl: conversionResult.link,
        timestamp: Date.now(),
        success: conversionResult.success,
        message: conversionResult.message
      };
      
      setResult(newResult);
      
      // Add to history only if successful
      if (conversionResult.success) {
        setHistory(prev => [newResult, ...prev].slice(0, 20)); // Keep only last 20 items
      }
      
      setIsConverting(false);
      
      if (conversionResult.success) {
        toast({
          title: "Link converted successfully",
          description: "Your direct download link is ready to use!",
        });
      } else {
        toast({
          title: "Conversion failed",
          description: conversionResult.message || "An error occurred during conversion.",
          variant: "destructive",
        });
      }
    }, 800);
  };
  
  const handleCopyLink = async () => {
    if (result?.directUrl) {
      const copied = await copyLink(result.directUrl);
      if (copied) {
        toast({
          title: "Link copied",
          description: "Direct download link copied to clipboard!",
        });
      } else {
        toast({
          title: "Copy failed",
          description: "Failed to copy link to clipboard.",
          variant: "destructive",
        });
      }
    }
  };
  
  const handleClear = () => {
    setInputUrl("");
    setResult(null);
  };

  return (
    <motion.div
      id="converter"
      className="w-full max-w-3xl mx-auto px-4 pt-24 pb-12"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="text-center mb-8">
        <motion.div 
          className="inline-block p-3 rounded-full bg-primary/10 mb-4"
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.5 }}
        >
          <Link size={28} className="text-primary" />
        </motion.div>
        <motion.h2 
          className="text-3xl font-bold tracking-tight mb-2"
          initial={{ y: 10, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.5 }}
        >
          Drive Link Generator
        </motion.h2>
        <motion.p 
          className="text-muted-foreground max-w-md mx-auto"
          initial={{ y: 10, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.5 }}
        >
          Transform Google Drive sharing links into direct download links instantly
        </motion.p>
      </div>

      <motion.div 
        className="glass-card rounded-2xl p-8"
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.5, duration: 0.5 }}
      >
        <form onSubmit={handleConvert} className="space-y-4">
          <div className="space-y-2">
            <label htmlFor="driveUrl" className="text-sm font-medium">
              Google Drive URL
            </label>
            <div className="relative">
              <input
                id="driveUrl"
                type="url"
                value={inputUrl}
                onChange={(e) => setInputUrl(e.target.value)}
                placeholder="https://drive.google.com/file/d/..."
                className={`glass-input w-full h-12 pl-12 pr-4 rounded-xl text-sm transition-all duration-300 ${
                  !isValidUrl && inputUrl ? "border-red-400 focus:ring-red-400" : ""
                }`}
              />
              <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground">
                <Link size={20} />
              </div>
              
              {!isValidUrl && inputUrl && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-red-500"
                >
                  <AlertCircle size={18} />
                </motion.div>
              )}
            </div>
            
            {!isValidUrl && inputUrl && (
              <motion.p
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="text-xs text-red-500 mt-1"
              >
                Please enter a valid Google Drive URL
              </motion.p>
            )}
          </div>

          <div className="flex items-center justify-between gap-4 pt-2">
            {result && (
              <button
                type="button"
                onClick={handleClear}
                className="px-4 py-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors rounded-lg"
              >
                Clear
              </button>
            )}
            
            <motion.button
              type="submit"
              disabled={isConverting || (!isValidUrl && inputUrl !== "")}
              className={`ml-auto px-6 py-2.5 rounded-xl bg-primary text-primary-foreground font-medium text-sm transition-all duration-300 ${
                isConverting || (!isValidUrl && inputUrl !== "")
                  ? "opacity-70 cursor-not-allowed"
                  : "hover:bg-primary/90"
              }`}
              whileHover={{ scale: isConverting || (!isValidUrl && inputUrl !== "") ? 1 : 1.03 }}
              whileTap={{ scale: isConverting || (!isValidUrl && inputUrl !== "") ? 1 : 0.98 }}
            >
              {isConverting ? (
                <span className="flex items-center gap-2">
                  <svg className="animate-spin h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Converting...
                </span>
              ) : (
                <span className="flex items-center gap-2">
                  Generate Direct Link <ArrowRight size={16} />
                </span>
              )}
            </motion.button>
          </div>
        </form>

        <AnimatePresence>
          {result && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
              className="mt-8 pt-6 border-t border-border"
            >
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className={`p-1.5 rounded-full ${result.success ? "bg-green-100 text-green-600" : "bg-red-100 text-red-600"}`}>
                    {result.success ? <Check size={18} /> : <XCircle size={18} />}
                  </div>
                  <div>
                    <h3 className="text-sm font-medium">
                      {result.success ? "Direct Download Link Created" : "Conversion Failed"}
                    </h3>
                    <p className="text-xs text-muted-foreground">
                      {result.success
                        ? "Your direct download link is ready to use"
                        : result.message || "Unable to generate a direct link"}
                    </p>
                  </div>
                </div>

                {result.success && (
                  <div className="bg-secondary/50 rounded-xl p-4 relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-1 h-full bg-primary"></div>
                    <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 justify-between">
                      <div className="truncate max-w-full sm:max-w-xs md:max-w-md">
                        <p className="text-xs text-muted-foreground mb-1">Direct Link:</p>
                        <p className="text-sm font-medium truncate">{result.directUrl}</p>
                      </div>
                      <div className="flex items-center gap-2 mt-2 sm:mt-0 ml-auto">
                        <a
                          href={result.directUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="p-2 rounded-lg hover:bg-secondary transition-colors"
                          aria-label="Open direct link"
                        >
                          <ExternalLink size={18} className="text-muted-foreground" />
                        </a>
                        <button
                          onClick={handleCopyLink}
                          className="p-2 rounded-lg hover:bg-secondary transition-colors"
                          aria-label="Copy direct link"
                        >
                          {copyState.copied && copyState.text === result.directUrl ? (
                            <Check size={18} className="text-green-600" />
                          ) : (
                            <Copy size={18} className="text-muted-foreground" />
                          )}
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </motion.div>
  );
};

export default LinkConverter;
