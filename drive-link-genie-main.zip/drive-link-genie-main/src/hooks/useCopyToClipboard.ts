
import { useState } from 'react';

interface CopyToClipboardState {
  copied: boolean;
  error: boolean;
  text: string | null;
}

type CopyToClipboardHook = [
  (text: string) => Promise<boolean>,
  CopyToClipboardState
];

/**
 * Custom hook for copying text to clipboard with state management
 * @returns Tuple with copy function and state
 */
export const useCopyToClipboard = (): CopyToClipboardHook => {
  const [state, setState] = useState<CopyToClipboardState>({
    copied: false,
    error: false,
    text: null
  });

  const copy = async (text: string): Promise<boolean> => {
    try {
      if (!navigator?.clipboard) {
        // Fallback for older browsers
        const textArea = document.createElement('textarea');
        textArea.value = text;
        
        // Make it invisible but part of the document
        textArea.style.position = 'fixed';
        textArea.style.top = '0';
        textArea.style.left = '0';
        textArea.style.opacity = '0';
        
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        
        const success = document.execCommand('copy');
        document.body.removeChild(textArea);
        
        if (!success) {
          throw new Error('Failed to copy text');
        }
        
        setState({
          copied: true,
          error: false,
          text
        });
        
        return true;
      }

      await navigator.clipboard.writeText(text);
      setState({
        copied: true,
        error: false,
        text
      });
      
      // Reset after 2 seconds
      setTimeout(() => {
        setState(prev => ({
          ...prev,
          copied: false
        }));
      }, 2000);
      
      return true;
    } catch (error) {
      setState({
        copied: false,
        error: true,
        text
      });
      return false;
    }
  };

  return [copy, state];
};
