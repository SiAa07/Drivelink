
import React, { useEffect } from "react";
import { motion } from "framer-motion";
import Header from "../components/Header";
import Footer from "../components/Footer";
import LinkConverter from "../components/LinkConverter";
import BatchConverter from "../components/BatchConverter";
import LinkHistory from "../components/LinkHistory";
import { ArrowRight, Link as LinkIcon, List, Shield, FileCode, Clock, Github } from "lucide-react";

const Index = () => {
  // Scroll to section based on hash
  useEffect(() => {
    const hash = window.location.hash;
    if (hash) {
      const element = document.querySelector(hash);
      if (element) {
        element.scrollIntoView({ behavior: "smooth" });
      }
    }
  }, []);

  const features = [
    {
      icon: <LinkIcon size={24} className="text-primary" />,
      title: "Direct Download Links",
      description: "Convert standard Google Drive sharing links to direct download links instantly."
    },
    {
      icon: <List size={24} className="text-primary" />,
      title: "Batch Processing",
      description: "Convert multiple links at once with our bulk processing feature."
    },
    {
      icon: <Shield size={24} className="text-primary" />,
      title: "Private & Secure",
      description: "Your links are processed entirely in your browser. We don't store any of your data."
    },
    {
      icon: <FileCode size={24} className="text-primary" />,
      title: "URL Validation",
      description: "Intelligent link validation ensures you're using valid Google Drive links."
    },
    {
      icon: <Clock size={24} className="text-primary" />,
      title: "Link History",
      description: "Access your previously converted links saved locally on your device."
    },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-background to-background">
      <Header />
      
      <main className="flex-1">
        {/* Hero section */}
        <section className="relative w-full pt-32 pb-24 overflow-hidden">
          <div className="container px-4 mx-auto relative z-10">
            <div className="flex flex-col items-center justify-center text-center max-w-3xl mx-auto">
              <motion.div
                className="flex items-center gap-2 bg-primary/10 text-primary rounded-full px-4 py-2 mb-8 text-sm font-medium"
                initial={{ y: -20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.5 }}
              >
                <span>100% Client-side Processing</span>
                <div className="w-1 h-1 rounded-full bg-primary"></div>
                <span>No Data Storage</span>
              </motion.div>
              
              <motion.h1
                className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6"
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.5, delay: 0.1 }}
              >
                Generate Direct Download Links for Google Drive
              </motion.h1>
              
              <motion.p
                className="text-lg text-muted-foreground mb-8 max-w-2xl"
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.5, delay: 0.2 }}
              >
                Transform standard Google Drive sharing links into direct download links instantly. 
                Streamline your file sharing experience with our simple, fast, and secure tool.
              </motion.p>
              
              <motion.div
                className="flex flex-col sm:flex-row items-center gap-4"
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.5, delay: 0.3 }}
              >
                <motion.a
                  href="#converter"
                  className="px-6 py-3 rounded-xl bg-primary text-primary-foreground font-medium transition-all hover:shadow-lg hover:bg-primary/90 flex items-center gap-2"
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.98 }}
                >
                  Get Started <ArrowRight size={18} />
                </motion.a>
                <a href="#how-it-works" className="text-muted-foreground font-medium hover:text-foreground transition-colors animate-link">
                  How It Works
                </a>
              </motion.div>
            </div>
          </div>
          
          {/* Background decorations */}
          <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
            <div className="absolute top-[10%] left-[5%] w-72 h-72 bg-primary/5 rounded-full blur-3xl"></div>
            <div className="absolute bottom-[10%] right-[5%] w-80 h-80 bg-primary/5 rounded-full blur-3xl"></div>
          </div>
        </section>
        
        {/* Converter section */}
        <LinkConverter />
        
        {/* Features section */}
        <section className="py-16 relative overflow-hidden">
          <div className="container px-4 mx-auto">
            <div className="text-center mb-12">
              <motion.h2
                className="text-3xl font-bold tracking-tight mb-4"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                Powerful Features
              </motion.h2>
              <motion.p
                className="text-muted-foreground max-w-2xl mx-auto"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
              >
                Everything you need to streamline your Google Drive file sharing
              </motion.p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {features.map((feature, index) => (
                <motion.div
                  key={index}
                  className="glass-card rounded-2xl p-6 flex flex-col h-full"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.1 * (index + 1) }}
                  whileHover={{ y: -5, transition: { duration: 0.2 } }}
                >
                  <div className="rounded-lg bg-primary/10 p-3 mb-4 w-max">
                    {feature.icon}
                  </div>
                  <h3 className="text-xl font-medium mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground text-sm">{feature.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
        
        {/* Batch converter section */}
        <BatchConverter />
        
        {/* How it works section */}
        <section id="how-it-works" className="py-16 relative overflow-hidden bg-secondary/30">
          <div className="container px-4 mx-auto">
            <div className="text-center mb-12">
              <motion.h2
                className="text-3xl font-bold tracking-tight mb-4"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
              >
                How It Works
              </motion.h2>
              <motion.p
                className="text-muted-foreground max-w-2xl mx-auto"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.1 }}
              >
                Our tool makes it simple to get direct download links in just a few steps
              </motion.p>
            </div>
            
            <div className="max-w-4xl mx-auto">
              <div className="relative">
                <div className="absolute left-[23px] top-0 bottom-0 w-[2px] bg-primary/20"></div>
                
                {[
                  {
                    title: "Paste Your Google Drive Link",
                    description: "Copy the sharing link from Google Drive and paste it into our converter tool."
                  },
                  {
                    title: "Generate Direct Link",
                    description: "Click the 'Generate Direct Link' button and our tool will instantly convert it to a direct download link."
                  },
                  {
                    title: "Use Your Direct Link",
                    description: "Copy the generated link and use it for direct downloading or sharing with others."
                  },
                  {
                    title: "Save for Later",
                    description: "Your converted links are saved in your browser's local storage for easy access later."
                  }
                ].map((step, index) => (
                  <motion.div
                    key={index}
                    className="flex gap-6 mb-8 relative z-10"
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: 0.2 * index }}
                  >
                    <div className="flex-shrink-0 flex items-center justify-center w-12 h-12 rounded-full bg-primary text-primary-foreground font-medium text-lg">
                      {index + 1}
                    </div>
                    <div className="pt-2">
                      <h3 className="text-lg font-medium mb-2">{step.title}</h3>
                      <p className="text-muted-foreground">{step.description}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </section>
        
        {/* History section */}
        <LinkHistory />
        
        {/* Call to action */}
        <section className="py-16 relative overflow-hidden">
          <div className="container px-4 mx-auto">
            <motion.div
              className="max-w-3xl mx-auto text-center"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <h2 className="text-3xl font-bold tracking-tight mb-4">Ready to Generate Direct Links?</h2>
              <p className="text-muted-foreground mb-8">
                Start converting your Google Drive links to direct download links today.
              </p>
              <motion.a
                href="#converter"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-primary text-primary-foreground font-medium transition-all hover:shadow-lg hover:bg-primary/90"
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.98 }}
              >
                Get Started <ArrowRight size={18} />
              </motion.a>
            </motion.div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default Index;
