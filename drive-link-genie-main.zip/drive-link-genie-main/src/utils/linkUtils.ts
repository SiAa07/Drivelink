
/**
 * Convert a Google Drive sharing link to a direct download link
 * @param url Google Drive sharing URL
 * @returns Direct download URL or error message
 */
export const convertToDriveDirectLink = (url: string): { success: boolean; link: string; message?: string } => {
  try {
    // Regular expression to extract file ID from Google Drive URL
    const fileIdRegex = /(?:https?:\/\/)?(?:www\.)?(?:drive\.google\.com)\/(?:file\/d\/|open\?id=)([a-zA-Z0-9_-]+)/;
    const match = url.match(fileIdRegex);
    
    if (!match || !match[1]) {
      // Try alternative format (for folder links or other formats)
      const altRegex = /(?:https?:\/\/)?(?:www\.)?(?:drive\.google\.com)\/(?:drive)?\/?(folders\/|uc\?id=)([a-zA-Z0-9_-]+)/;
      const altMatch = url.match(altRegex);
      
      if (!altMatch || !altMatch[2]) {
        return { 
          success: false, 
          link: url, 
          message: "Invalid Google Drive URL format. Please check your URL and try again." 
        };
      }
      
      // For folder links, we can't generate direct download links
      if (altMatch[1] === 'folders/') {
        return {
          success: false,
          link: url,
          message: "Direct download links cannot be generated for folders, only for individual files."
        };
      }
      
      const fileId = altMatch[2];
      return {
        success: true,
        link: `https://drive.google.com/uc?export=download&id=${fileId}`
      };
    }
    
    const fileId = match[1];
    return {
      success: true,
      link: `https://drive.google.com/uc?export=download&id=${fileId}`
    };
  } catch (error) {
    return {
      success: false,
      link: url,
      message: "An error occurred while processing your link. Please try again."
    };
  }
};

/**
 * Validates if a URL is a Google Drive URL
 * @param url URL to validate
 * @returns Boolean indicating if URL is valid
 */
export const isValidDriveUrl = (url: string): boolean => {
  const driveUrlRegex = /^(?:https?:\/\/)?(?:www\.)?drive\.google\.com\//i;
  return driveUrlRegex.test(url);
};

/**
 * Process multiple URLs at once
 * @param urls Array of Google Drive URLs
 * @returns Array of processed results
 */
export const processBatchLinks = (urls: string[]): Array<{
  originalUrl: string;
  directUrl: string;
  success: boolean;
  message?: string;
}> => {
  return urls.map(url => {
    const result = convertToDriveDirectLink(url.trim());
    return {
      originalUrl: url.trim(),
      directUrl: result.link,
      success: result.success,
      message: result.message
    };
  });
};

/**
 * Extracts a file name from a Google Drive URL if possible
 * @param url Google Drive URL
 * @returns File name or null if not found
 */
export const extractFileName = (url: string): string | null => {
  try {
    // Try to extract from URL parameters
    const urlObj = new URL(url);
    if (urlObj.searchParams.has('title')) {
      return urlObj.searchParams.get('title');
    }
    
    // If no title parameter, return null (we could fetch it if API was available)
    return null;
  } catch (error) {
    return null;
  }
};

/**
 * Generates a short link preview
 * @param url URL to shorten for display
 * @returns Shortened URL string
 */
export const generateLinkPreview = (url: string): string => {
  try {
    const MAX_LENGTH = 50;
    if (url.length <= MAX_LENGTH) return url;
    
    const urlObj = new URL(url);
    const domain = urlObj.hostname;
    const path = urlObj.pathname;
    
    if (domain.length + 10 >= MAX_LENGTH) {
      return domain.substring(0, MAX_LENGTH - 3) + '...';
    }
    
    const available = MAX_LENGTH - domain.length - 4; // 4 for '://' and '...'
    const firstPart = path.substring(0, available / 2);
    const lastPart = path.substring(path.length - available / 2);
    
    return `${domain}${firstPart}...${lastPart}`;
  } catch (error) {
    if (url.length <= MAX_LENGTH) return url;
    return url.substring(0, MAX_LENGTH - 3) + '...';
  }
};
